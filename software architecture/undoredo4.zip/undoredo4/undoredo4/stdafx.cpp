// stdafx.cpp : ֻ������׼�����ļ���Դ�ļ�
// undoredo4.pch ����ΪԤ����ͷ
// stdafx.obj ������Ԥ����������Ϣ

#include "stdafx.h"
#include <iostream>  
#include <stack>  
#include <string>  
#ifndef _COMMAND_HPP  
#define _COMMAND_HPP  

class Command
{
public:
	Command()
	{

	}
	virtual ~Command() 
	{
	
	}

	virtual void Execute() = 0;
};


class InputCommand : public Command
{
public:

	InputCommand(const std::string &input)
	{
		mInput = input;
	}
	~InputCommand()
	{

	}

	void Execute()
	{
		printf("current string: %s\n", mInput.c_str());
	}

private:

	std::string mInput;
};
class Commander
{
public:
	Commander(Command *pCmd)
	{
		mUndo.push(pCmd);
	}
	~Commander()
	{
		while (false == mUndo.empty())
		{
			delete mUndo.top();
			mUndo.pop();
		}
		while (false == mRedo.empty())
		{
			delete mRedo.top();
			mRedo.pop();
		}
	}

	void ExecuteCommand(Command *pCmd)
	{
		pCmd->Execute();
		mUndo.push(pCmd);
	}

	void Undo()
	{
		if (mUndo.size() < 2)
		{
			printf("undo failed.\n");
			return;
		}

		printf("undo:\n");
		auto pCmd = mUndo.top(); 
		mRedo.push(pCmd); 
		mUndo.pop();

  
		pCmd = mUndo.top();

		pCmd->Execute();
	}

	void Redo()
	{
		if (mRedo.empty())
		{  
			printf("redo failed.\n");
			return;
		}

		printf("redo:\n");

		auto pCmd = mRedo.top();

		pCmd->Execute();

		mRedo.pop();

		mUndo.push(pCmd);
	}

private:
	std::stack< Command* > mUndo;
	std::stack< Command* > mRedo;
};

#endif  

int main()
{
	Commander *p = new Commander(new InputCommand("test"));

	p->ExecuteCommand(new InputCommand("baixue"));
	p->ExecuteCommand(new InputCommand("666"));
	p->ExecuteCommand(new InputCommand("1234"));
	p->Undo();
	p->Undo();

	//undo���м��������ַ��� insert ���� baixue 
	p->ExecuteCommand(new InputCommand("insert"));
	p->Undo(); 
	p->Undo();
	p->Undo(); 
	p->Redo(); 
	p->Redo(); 
	p->Redo();
	p->ExecuteCommand(new InputCommand("insert again"));
	p->Undo();
	p->Redo();
	p->Redo();
	p->Redo();
	delete p;
	system("pause");
	return 0;
}